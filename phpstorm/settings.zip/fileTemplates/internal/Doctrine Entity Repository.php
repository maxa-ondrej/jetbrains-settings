<?php

namespace ${NAMESPACE};

use ${ENTITY_NAMESPACE}\\${NAME};
use App\Model\Database\EntityRepository;

/**
 * @extends Repository<${NAME}>
 */
class ${NAME}Repository extends Repository
{
}
